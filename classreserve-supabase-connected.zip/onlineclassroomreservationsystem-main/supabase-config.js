// ClassReserve Supabase browser configuration.
// It is safe to use the Supabase Project URL and Publishable key here.
// NEVER put a service_role key or any secret key in this file.
window.CLASSRESERVE_SUPABASE_URL = "PASTE_YOUR_PROJECT_URL_HERE";
window.CLASSRESERVE_SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_SB_PUBLISHABLE_KEY_HERE";
