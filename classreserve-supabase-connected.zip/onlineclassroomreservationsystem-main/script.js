import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

document.addEventListener("DOMContentLoaded", async () => {
    const SUPABASE_URL = window.CLASSRESERVE_SUPABASE_URL;
    const SUPABASE_KEY = window.CLASSRESERVE_SUPABASE_PUBLISHABLE_KEY;
    const loginSection = document.getElementById("login-section");
    const dashboardSection = document.getElementById("dashboard-section");
    const loginForm = document.getElementById("login-form");
    const loginError = document.getElementById("login-error");
    const loginButton = document.getElementById("login-button");
    const dashboardTitle = document.getElementById("dashboard-title");
    const welcomeMessage = document.getElementById("welcome-message");
    const dashboardContent = document.getElementById("dashboard-content");
    const logoutButton = document.getElementById("logout-button");
    const appMessage = document.getElementById("app-message");

    let supabase;
    let currentUser = null;
    let currentProfile = null;

    if (!SUPABASE_URL || !SUPABASE_KEY || SUPABASE_URL.includes("PASTE_") || SUPABASE_KEY.includes("PASTE_")) {
        showLoginError("Supabase is not configured yet. Add your Project URL and Publishable key to supabase-config.js.");
        loginButton.disabled = true;
        return;
    }

    supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

    loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        clearMessages();
        loginButton.disabled = true;
        loginButton.textContent = "Logging in...";

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });

        if (error) {
            showLoginError("Login failed. Check your email and password, then try again.");
            resetLoginButton();
            return;
        }

        currentUser = data.user;
        const { data: profile, error: profileError } = await supabase
            .from("profiles")
            .select("id, username, role")
            .eq("id", currentUser.id)
            .single();

        if (profileError || !profile) {
            await supabase.auth.signOut();
            currentUser = null;
            showLoginError("Your account is signed in, but its ClassReserve profile was not found. Ask the administrator to check the profiles table.");
            resetLoginButton();
            return;
        }

        currentProfile = profile;
        showDashboard();
        resetLoginButton();
    });

    logoutButton.addEventListener("click", async () => {
        await supabase.auth.signOut();
        currentUser = null;
        currentProfile = null;
        loginForm.reset();
        dashboardSection.hidden = true;
        loginSection.hidden = false;
        clearMessages();
    });

    document.querySelectorAll("[data-view]").forEach((button) => {
        button.addEventListener("click", () => renderView(button.dataset.view));
    });

    function resetLoginButton() {
        loginButton.disabled = false;
        loginButton.textContent = "Log In";
    }

    function showLoginError(message) {
        loginError.textContent = message;
        loginError.hidden = false;
    }

    function clearMessages() {
        loginError.hidden = true;
        loginError.textContent = "";
        appMessage.textContent = "";
    }

    function setMessage(message, isError = false) {
        appMessage.textContent = message;
        appMessage.className = isError ? "error-message" : "success-message";
    }

    function showDashboard() {
        loginSection.hidden = true;
        dashboardSection.hidden = false;
        dashboardTitle.textContent = `${currentProfile.role} Dashboard`;
        welcomeMessage.textContent = `Welcome, ${currentProfile.username}! You are logged in as ${currentProfile.role}.`;
        renderView("dashboard");
    }

    async function renderView(view) {
        if (!currentUser || !currentProfile) return;
        clearMessages();

        if (view === "dashboard") {
            dashboardContent.innerHTML = `
                <h3>Welcome to ClassReserve!</h3>
                <p>Use the menu to browse classrooms and manage reservations.</p>
                <p><strong>Account type:</strong> ${escapeHTML(currentProfile.role)}</p>
            `;
        }

        if (view === "rooms") {
            const rooms = [
                { name: "Classroom 101", capacity: 30, building: "Main Building" },
                { name: "Classroom 102", capacity: 40, building: "Main Building" },
                { name: "Computer Laboratory", capacity: 35, building: "Technology Building" }
            ];
            dashboardContent.innerHTML = `
                <h3>Available Classrooms</h3>
                <p>Select a classroom to request a reservation.</p>
                <div class="room-grid">
                    ${rooms.map(room => `
                        <article class="room-card">
                            <h4>${escapeHTML(room.name)}</h4>
                            <p>Capacity: ${room.capacity} people</p>
                            <p>${escapeHTML(room.building)}</p>
                            ${currentProfile.role === "Admin" ? "" : `<button type="button" data-book-room="${escapeHTML(room.name)}">Request Reservation</button>`}
                        </article>
                    `).join("")}
                </div>
            `;
            dashboardContent.querySelectorAll("[data-book-room]").forEach(button => {
                button.addEventListener("click", () => showReservationForm(button.dataset.bookRoom));
            });
        }

        if (view === "reservations") {
            await loadReservations();
        }
    }

    function showReservationForm(roomName) {
        dashboardContent.innerHTML = `
            <h3>Request ${escapeHTML(roomName)}</h3>
            <form id="reservation-form" class="reservation-form">
                <label for="reservation-date">Reservation date</label>
                <input id="reservation-date" type="date" min="${new Date().toISOString().slice(0, 10)}" required>
                <label for="reservation-time">Reservation time</label>
                <input id="reservation-time" type="text" placeholder="9:00 AM - 11:00 AM" required>
                <button type="submit">Submit Reservation</button>
                <button type="button" class="secondary-button" id="cancel-reservation">Cancel</button>
            </form>
        `;
        document.getElementById("cancel-reservation").addEventListener("click", () => renderView("rooms"));
        document.getElementById("reservation-form").addEventListener("submit", async (event) => {
            event.preventDefault();
            const reservationDate = document.getElementById("reservation-date").value;
            const reservationTime = document.getElementById("reservation-time").value.trim();
            const { error } = await supabase.from("reservations").insert({
                user_id: currentUser.id,
                username: currentProfile.username,
                role: currentProfile.role,
                classroom: roomName,
                reservation_date: reservationDate,
                reservation_time: reservationTime,
                status: "Pending"
            });
            if (error) {
                setMessage(`Could not submit reservation: ${error.message}`, true);
                return;
            }
            setMessage("Reservation request submitted successfully. Status: Pending.");
            await loadReservations();
        });
    }

    async function loadReservations() {
        dashboardContent.innerHTML = "<p>Loading reservations...</p>";
        const { data: reservations, error } = await supabase
            .from("reservations")
            .select("id, username, role, classroom, reservation_date, reservation_time, status, created_at")
            .order("created_at", { ascending: false });

        if (error) {
            dashboardContent.innerHTML = "<h3>Reservations</h3><p>Could not load reservations. Please check your table and Row Level Security policies.</p>";
            setMessage(error.message, true);
            return;
        }

        if (!reservations || reservations.length === 0) {
            dashboardContent.innerHTML = `<h3>${currentProfile.role === "Admin" ? "All Reservations" : "My Reservations"}</h3><p>No reservation requests found.</p>`;
            return;
        }

        const isAdmin = currentProfile.role === "Admin";
        const rows = reservations.map(reservation => `
            <tr>
                ${isAdmin ? `<td>${escapeHTML(reservation.username)}</td><td>${escapeHTML(reservation.role)}</td>` : ""}
                <td>${escapeHTML(reservation.classroom)}</td>
                <td>${escapeHTML(reservation.reservation_date)}</td>
                <td>${escapeHTML(reservation.reservation_time)}</td>
                <td>${escapeHTML(reservation.status)}</td>
                ${isAdmin ? `<td><select data-status-id="${reservation.id}" aria-label="Update status for reservation ${reservation.id}">
                    <option value="Pending" ${reservation.status === "Pending" ? "selected" : ""}>Pending</option>
                    <option value="Approved" ${reservation.status === "Approved" ? "selected" : ""}>Approved</option>
                    <option value="Rejected" ${reservation.status === "Rejected" ? "selected" : ""}>Rejected</option>
                </select></td>` : ""}
            </tr>
        `).join("");

        dashboardContent.innerHTML = `
            <h3>${isAdmin ? "All Reservations" : "My Reservations"}</h3>
            <div class="table-container"><table>
                <thead><tr>
                    ${isAdmin ? "<th>Username</th><th>Role</th>" : ""}
                    <th>Classroom</th><th>Date</th><th>Time</th><th>Status</th>
                    ${isAdmin ? "<th>Update status</th>" : ""}
                </tr></thead>
                <tbody>${rows}</tbody>
            </table></div>
        `;

        if (isAdmin) {
            dashboardContent.querySelectorAll("[data-status-id]").forEach(select => {
                select.addEventListener("change", async () => {
                    const id = Number(select.dataset.statusId);
                    const { error: updateError } = await supabase
                        .from("reservations")
                        .update({ status: select.value })
                        .eq("id", id);
                    if (updateError) {
                        setMessage(`Could not update reservation: ${updateError.message}`, true);
                    } else {
                        setMessage("Reservation status updated.");
                    }
                });
            });
        }
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, character => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
        })[character]);
    }

    // Restore an existing Supabase session after a page refresh.
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
        currentUser = session.user;
        const { data: profile } = await supabase
            .from("profiles")
            .select("id, username, role")
            .eq("id", currentUser.id)
            .single();
        if (profile) {
            currentProfile = profile;
            showDashboard();
        } else {
            await supabase.auth.signOut();
        }
    }
});
