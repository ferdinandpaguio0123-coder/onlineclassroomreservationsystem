// ClassReserve Supabase browser configuration.
// It is safe to use the Supabase Project URL and Publishable key here.
// NEVER put a service_role key or any secret key in this file.
window.CLASSRESERVE_SUPABASE_URL = "https://gjmoavfwfxekfiztoenw.supabase.co/rest/v1/
";
window.CLASSRESERVE_SUPABASE_PUBLISHABLE_KEY = "sb_publishable_8RavJWcynPnCPfNBxJQurw_LOYPupr0
";

