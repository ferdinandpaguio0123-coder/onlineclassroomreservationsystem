// ClassReserve Supabase browser configuration.
// It is safe to use the Supabase Project URL and Publishable key here.
// NEVER put a service_role key or any secret key in this file.
window.CLASSRESERVE_SUPABASE_URL = "sb_publishable_8RavJWcynPnCPfNBxJQurw_LOYPupr0
";
window.CLASSRESERVE_SUPABASE_PUBLISHABLE_KEY = "sb_secret_Awguty32-p4GAJdYuiZ2Eg_MeOSRfCO
";

